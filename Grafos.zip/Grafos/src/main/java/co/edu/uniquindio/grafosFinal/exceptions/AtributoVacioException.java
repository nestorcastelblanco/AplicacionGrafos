package co.edu.uniquindio.grafosFinal.exceptions;

public class AtributoVacioException extends Exception {

    public AtributoVacioException(String mensaje) {
        super(mensaje);
    }
}