package co.edu.uniquindio.grafosFinal.exceptions;

public class InformacionRepetidaException extends Exception {

    public InformacionRepetidaException(String mensaje) {
        super(mensaje);
    }
}